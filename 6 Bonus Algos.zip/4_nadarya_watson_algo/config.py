# Phemex (xP)
xP_KEY = ''
xP_SECRET = ''
