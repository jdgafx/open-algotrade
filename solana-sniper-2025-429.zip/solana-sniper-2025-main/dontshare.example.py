










































key = 'SOLANA PRIVATE KEY'
sol_key = key 
birdeye = 'BIRDEYE KEY'
rpc_url = 'hkjlsdhksdjlh'
moondev_api_key = 'jlsjk;dslkdjs'