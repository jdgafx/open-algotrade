# 2025 Solana Sniper

we are building out a solana sniper to buy tokens when they launch this will act as a very good scanner for finding new tokens before anybody else does 

## main.py is the entry point that runs the bot
## nice_funcs.py is where a lot of nice functions are
## get_new_tokens.py is the scanner and filter
