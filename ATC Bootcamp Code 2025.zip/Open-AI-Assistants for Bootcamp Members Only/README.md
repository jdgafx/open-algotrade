# Open AI Assistants to Build 100 AI 

personally, im going to be using my 100 ai to algo trade for me as thats where i have been spending all of my time. 

custom gpt for assistants: https://chat.openai.com/g/g-RnBKKiEhD-swarm-assistants-ai

docs - https://platform.openai.com/docs/assistants/overview 

Todo 
1. go through assistants docs: https://platform.openai.com/docs/assistants/overview 
- have the outputed backtest put into a file
- upload data to the ai so it can analyze it
- ai to analyze time of market moves
- 

RBI System for algo trading - 4-6 hours
- R - Research - ai to research trading strategies
    - High ROI, High sharpe (1.5+), low drawdown
- B - Backtest - ai to backtest trading strategies
- I - Implement - ai to implement trading strategies
.. do this whole process automatically with ai 24/7

Doc Notes
-  Code Interpreter, Retrieval, and Function calling
- Assistant: instruction (how they should respond) --> pick a MODEL --> tools like code intereperter --> functions 

TO UNDERSTAND
- STEP 1 - Create an AI Assistant - this is the AI that you create and can call on at anytime. Example, we are building a trader AI that can research, code and backtest trading strategies

- STEP 2 - Create a Thread - you and your friend laquisha are texting, you guys have a thread of messages on imessage or bunky androids.. thats a thread, but with your above AI. Threads dont have a limit to messages. Open ai will handle all that. 

- STEP 3 - add messages to a thread -- you and your friend laquisha have messages all saved to one thread. thats just how it is with thread OAI


ideas =
- make a master ai to montior my 1 mil ai and priotize the best performing ones

t