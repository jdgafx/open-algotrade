# Hyper Liquid Altcoin Bot

we are building out a trading bot for hyper liquid to get expsoure to the newest altcoins without the risk of centralized exchanges. we all saw what happened with FTX, so we need to avoid centralized exchange. 

How to set up on hyperliquid-
1. only way to get access to hyperliquid and save huge on fees: https://app.hyperliquid.xyz/join/MOONDEV 
2. set up arbitrum https://cointelegraph.com/news/how-to-add-arbitrum-to-metamask 
3. https://support.metamask.io/hc/en-us/articles/360015289632-How-to-export-an-account-s-private-key#:~:text=On%20the%20'Account%20details'%20page,private%20key%20to%20your%20clipboard. 
