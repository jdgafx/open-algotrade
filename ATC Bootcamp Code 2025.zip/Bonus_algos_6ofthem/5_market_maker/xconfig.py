# place your keys below to phemex or the exhange you want

phemex_KEY = ''
phemex_SECRET = ''