'''
Setting up a new computer 2024-
Must download conda and set up the below, then bring in the folders below
1. Download anaconda 

Create 1st Enviroment-
2. conda create --name algotrader python=3.8.5
3. conda activate algotrader
conda info --envs

pip install backtrader Backtesting ccxt requests pandas yfinance scikit-learn numpy matplotlib
pandas-ta
pip instal backtrader
pip install Backtesting

create the environment, adding packages, 
activating enviroment
start another enviroment
pip installing properly, and then being 
able to use that all in VScode and import properly
'''