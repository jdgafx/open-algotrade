####################### ​Coding Basics 2024

# step 1 - download visual studio code

print('write code')
# LOOPS, FUNCTIONS, WHILE LOOPS, VARIABLEs

# what to do when you get stuck

# important packages to learn

# pip install 
import pandas as pd 
import ccxt 
import numpy as np 
import datetime 
import ta 
import backtrader 

# important code to know  - PYTHON 3 // 

# 4 hours per day

# variable
# loops
# functions


# download and set up anaconda and a virtual enviroment

# best resources for learning code basics